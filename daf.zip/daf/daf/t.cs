﻿namespace daf
{
    internal class t
    {
    }
}