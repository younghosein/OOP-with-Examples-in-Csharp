﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace daf
{
    class Person
    {
        public string Name;
        public Person(string Name)
        {
            this.Name = Name;
        }
    }
}
